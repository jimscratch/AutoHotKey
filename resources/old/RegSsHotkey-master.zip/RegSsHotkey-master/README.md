# RegSsHotkey
由于 [Shadowsocks](https://github.com/shadowsocks/shadowsocks-windows) 启动时不会自动注册已设置的快捷键，每次开机后都要手工注册一遍，很浪费时间，所以就写了这个工具代替手工操作。

![RegSsHotkey 截图](https://github.com/tmplinshi/RegSsHotkey/raw/master/RegSsHotkey.png)

下载地址: https://github.com/tmplinshi/RegSsHotkey/releases
